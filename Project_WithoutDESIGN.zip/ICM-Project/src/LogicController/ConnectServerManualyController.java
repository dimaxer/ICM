package LogicController;

public class ConnectServerManualyController extends BaseController {
}
