package Gui;

import javafx.fxml.Initializable;

public interface BaseFx extends Initializable {
	
}
