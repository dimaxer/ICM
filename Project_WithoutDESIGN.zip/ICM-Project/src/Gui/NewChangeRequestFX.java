package Gui;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.swing.JFileChooser;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.validation.RequiredFieldValidator;

import Common.AttachedFile;
import LogicController.NewChangeRequestController;
import Utilities.MessageObject;
import client.Client;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;

public class NewChangeRequestFX implements BaseFx {

	@FXML
	private JFXTextField jfxinfSys;

	@FXML
	private JFXTextField jfxrequestedChange;

	@FXML
	private JFXTextField jfxsituation;

	@FXML
	private JFXTextField jfxreasons;

	@FXML
	private JFXTextField jfxnotes;

	@FXML
	private ImageView error;

	@FXML
	private Button AddFiles;

	@FXML
	private Text fileName;

	@FXML
	private Button submit;

	@FXML
	private ListView listView;

	@FXML
	private JFXButton attachFiles;

	@FXML
	private JFXButton uploadFiles;

	@FXML
	private AnchorPane browseFiles;

	List<File> selectedFiles;

	private String date, infSys, requestedChange, situation, changeReasons, notes;

	private AttachedFile attachedFile;

	private NewChangeRequestController newChangeRequestController;

	private ArrayList<Object> args;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		AddFiles.setDefaultButton(true);
		submit.setDefaultButton(true);
		newChangeRequestController = new NewChangeRequestController();
		args = new ArrayList<Object>();
	}

	/**
	 * This method handles the form when submit was pressed
	 */
	@FXML
	public void submitWasPressed(ActionEvent event) {
		setValdiator();
		initStringFieldValues();

		if (infSys.isEmpty() || situation.isEmpty() || requestedChange.isEmpty())
			validateFields(); // method extracted
		else {
			addFieldsToArgs();
			args.set(6, attachedFile);
			newChangeRequestController.submitWasPressed(args);

		}
	}

	private void initStringFieldValues() {
		date = DateTimeFormatter.ofPattern("dd/MM/yyyy").format(LocalDate.now());
		infSys = jfxinfSys.getText();
		situation = jfxsituation.getText();
		requestedChange = jfxrequestedChange.getText();
		changeReasons = jfxreasons.getText();
		notes = jfxnotes.getText();
	}

	/**
	 * This method adds the field values to args ArrayList
	 * 
	 * @param args
	 * @return ArrayList that includes the field arguments
	 */
	private void addFieldsToArgs() {
		args.add(date);
		args.add(infSys);
		args.add(requestedChange);
		args.add(situation);
		args.add(changeReasons);
		args.add(notes);
		args.add(null); // Attached File
		args.add("New");
		args.add("Active");
		args.add(Client.getInstance().getCurrentUser().getId());
	}

	/**
	 * This method validates the fields
	 */
	private void validateFields() {
		jfxinfSys.validate();
		jfxsituation.validate();
		jfxrequestedChange.validate();
		jfxreasons.validate();
		jfxnotes.validate();
	}

	/**
	 * This method sets field validators
	 */
	public void setValdiator() {
		RequiredFieldValidator validator = new RequiredFieldValidator();

		jfxinfSys.getValidators().add(validator);
		jfxsituation.getValidators().add(validator);
		jfxrequestedChange.getValidators().add(validator);
		jfxreasons.getValidators().add(validator);
		jfxnotes.getValidators().add(validator);

		validator.setMessage("*required");
	}

	@FXML
	public void backWasPressed(ActionEvent event) {
		newChangeRequestController.switchScene("Panel");

	}

	/**
	 * if the request was created successfully this method uploads the files to the
	 * server if there are any
	 * 
	 * @param msg
	 */
	public void newCRHandler(MessageObject msg) {
		MessageObject message = (MessageObject) msg;
		if ((Boolean) message.getArgs().get(0))// [True|False]
		{
			String requestID = (String) message.getArgs().get(1);
			// upload all the files that were attached to the request
			if (selectedFiles != null)
				for (File file : selectedFiles)
					newChangeRequestController.sendFileToServer(file, requestID);

			newChangeRequestController.switchScene("Panel");
		}

	}

	@FXML
	public void addFilesWasPressed(ActionEvent event) {
		browseFiles.setVisible(true);
		if (listView.getItems() != null)
			listView.getItems().clear();
		if (selectedFiles != null)
			selectedFiles = null;

	}

	/**
	 * create a list of files that are chosen by the user
	 * 
	 * @param event
	 */
	@FXML
	public void attachFilesWasPressed(ActionEvent event) {
		FileChooser fileChooser = new FileChooser();
		selectedFiles = fileChooser.showOpenMultipleDialog(null);
		if (selectedFiles != null) {
			for (int i = 0; i < selectedFiles.size(); i++)
				listView.getItems().add(selectedFiles.get(i).getName());

		} else {
			System.out.println("no files were selected");
		}

	}

	@FXML
	public void closeAttachFilesWasPressed(ActionEvent event) {
		browseFiles.setVisible(false);
	}

	/**
	 * A method to clear all the fields in this form
	 * 
	 * @author Raz Malka
	 */
	public void clearFields() {
		// TODO Auto-generated method stub
		jfxinfSys.setText("");
		jfxsituation.setText("");
		jfxrequestedChange.setText("");
		jfxreasons.setText("");
		jfxnotes.setText("");
		fileName.setText("");
		selectedFiles = null;
	}
}
